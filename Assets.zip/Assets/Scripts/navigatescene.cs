using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class navigatescene : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void startbutton()
    {
        SceneManager.LoadScene("GameEngine");
    }
    public void endbutton()
    {
        Application.Quit();
    }
}
